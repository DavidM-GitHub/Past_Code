import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
//PLAYER 2
public class Client {

	public Client() throws Exception{
		//Client establishes a connection to the server using socket
		Socket socket = new Socket("localhost", 3004);
		PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
		BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		String reply,userInput;
		Scanner scan=new Scanner(System.in);
		int chance=0;
		
		
		do{
			chance=0;
			reply=in.readLine();
			System.out.println(reply);
		//Player2 (Client) has 5 attempts to guess letters in the word by sending these to Player1 (Server
		do {
			System.out.print("Enter a letter: ");
			userInput=scan.nextLine();
			chance++;
			out.println(userInput);
			reply=in.readLine();
			System.out.println(reply);
		}while(chance<5);
		
		//The client should then guess the word, and server responds with correct or incorrect
		System.out.print("Guess the word: ");
		userInput=scan.nextLine();
		out.println(userInput);
		
		reply=in.readLine();
		System.out.println(reply);
		//Client should be allowed to play again if they want (with a new word), or they can exit.
		System.out.print("Do you wish to play again?(Yes/No) ");
		userInput=scan.nextLine();
		out.println(userInput);
		}while(userInput.equalsIgnoreCase("Yes"));
		
		
		
		out.close();
		in.close();
		socket.close();
		}
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		new Client();
	}
	}


