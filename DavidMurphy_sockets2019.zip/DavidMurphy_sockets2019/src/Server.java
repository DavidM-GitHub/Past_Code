import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
//PLAYER 1
	public Server() throws Exception{
		
		ServerSocket server=new ServerSocket(3004);
		
		Socket clientSocket=server.accept();
		
		BufferedReader in =new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
		PrintWriter out=new PrintWriter(clientSocket.getOutputStream(),true);
		Scanner scan=new Scanner(System.in);
		String answer;
		int chance;
		String inputLine;
		boolean found=false;
		
		//Server initiates game by asking the Player1(Server) to enter a word
		do {
			chance=0;
			System.out.print("Player 1... Enter a word: ");
			answer=scan.nextLine();
			out.println("Player 2... You have 5 attempts to guess the letters in the word");
		//Player1 (Server) responds to Player 2(client) each time by sending a message to let them 
		//know if the letter exists and if so in which position in the word
			do {
				found=false;
				inputLine=in.readLine();
				chance++;
				System.out.println("Attempt:" +inputLine);
				String returnStatement="";
				for(int i=0;i<answer.length();i++) {
					if(inputLine.charAt(0)==answer.charAt(i)){
						System.out.println("Character guessed found at position "+(i+1)+"... ");
						found=true;
						returnStatement=returnStatement+"Character guessed found at position "+(i+1)+"... ";
			}
			}
			if(!found) {
				System.out.println("Wrong answer...");
				out.println("Wrong answer...");
			}
			else {
				out.println(returnStatement);
			}
			}while(chance<5);
			
			
			inputLine=in.readLine();
			System.out.println("User guessed the word is: "+inputLine);
			if(inputLine.equalsIgnoreCase(answer)){
				System.out.println("Player 2 guessed the right answer!");
				out.println("You have guessed the right answer!");
			}
			else{
				System.out.println("Player 2 guessed the wrong answer!");
				out.println("You have guessed the wrong answer!");
			}
		
			inputLine=in.readLine();
			if(inputLine.equalsIgnoreCase("Yes")) {
				System.out.println("Player 2 wants to play again");
			}
		}while(inputLine.equalsIgnoreCase("Yes"));
			
		
			
		
		out.close();
		in.close();
		clientSocket.close();
		server.close();
	}
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		new Server();
	}

}
