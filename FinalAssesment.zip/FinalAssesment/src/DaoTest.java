import java.util.ArrayList;
import java.util.List;

public class DaoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ParkDAO pdao=new ParkDAO();

		User user=new User("dave@g.c","123","true");
		pdao.persistUser(user);
		
		User user2=new User("ben@g.c","123","false");
		pdao.persistUser(user2);
		
		List<User> usersFromDB=pdao.getAllUsers();
		for(User user1:usersFromDB) {
			System.out.println(user1.toString());
		}
		


//		Park p=new Park();
//		p.setName("Cabinteely Park");
//		p.setAddress("Cabinteely Park, Old Bray Road, Cabinteely, Dublin 18");
//		p.setHours("September 8.00am to 8.00pm October 8.00am to 7.00pm November - January 8.00am to 5.00pm February 8.00am to 6.00pm March 8.00am to 7.00pm April 8.00am to 8.00pm May, June, July, August 8.00am to 10.30pm");
//		p.setFacilities("Parking- Toilets - Playgrounds - Coffee Shop - Extensive walking paths - Concert venue (outdoor summer concerts)- Ice Cream vendor (Summer Time) - Chamber music venue (in Cabinteely House)G.A.A pitches - Soccer pitches - Trim Trail");
//		p.setNumber("(00353-1) 2054700\r\n");
//		p.setEmail("info@dlrcoco.ie\r\n");
//		
//		Park p1=new Park();
//		p1.setName("thorpe Park");
//		p1.setAddress("Old Bray Road, Cabinteely, Dublin 18");
//		p1.setHours("november - January 8.00am to 5.00pm February 8.00am to 6.00pm March 8.00am to 7.00pm April 8.00am to 8.00pm May, June, July, August 8.00am to 10.30pm");
//		p1.setFacilities("Coffee Shop - Extensive walking paths - Concert venue (outdoor summer concerts)- Ice Cream vendor (Summer Time) - Chamber music venue (in Cabinteely House)G.A.A pitches - Soccer pitches - Trim Trail");
//		p1.setNumber("2054700");
//		p1.setEmail("info@dlrcoco.ie");
//		
//		pdao.persistPark(p);
//		pdao.persistPark(p1);
//
//		List<Park> parks=new ArrayList<>();
//parks.add(p);
//parks.add(p1);
//		
//		Council c=new Council("Dun Laghoire",parks);
//		pdao.persistCouncil(c);
	}

}
