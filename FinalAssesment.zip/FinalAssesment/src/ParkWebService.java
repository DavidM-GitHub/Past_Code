import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

@Path("/sampleservice")
public class ParkWebService {

	static boolean loggedin;
	static boolean isadmin;

	//PARK METHODS
	@GET
    @Path("/hello")
    @Produces("text/plain")
    public String hello(){
        return "Hello World";    
    }	
	
	@GET
    @Path("/parks")
    @Produces("application/xml")
	public List<Park> listParks(){
		ParkDAO pdao=new ParkDAO();
		if(loggedin) {
		return pdao.getAllParks();
		}else 
		{
			System.out.println("Must Login to View Park Details");
			return null;
		}
	}
	
	@GET
    @Path("/park/{parkid}")
    @Produces("application/xml")
    public Park getPark(@PathParam("parkid")String parkid){
		ParkDAO pdao=new ParkDAO();
		if(!loggedin){
			System.out.println("Must Login to View Park Details");
			return null;
		}else {
			return pdao.getParkById(Integer.parseInt(parkid));	
		}
    }
	
	@POST
	@Path("/addpark/xml")
	@Consumes("application/xml")
	public String addPark(Park park) {		
		ParkDAO pdao=new ParkDAO();
		if(isadmin&&loggedin) {
		Park park1=new Park(park.getName(),park.getAddress(),park.getHours(),park.getFacilities(),park.getNumber(),park.getEmail());
		pdao.persistPark(park1);
		return "Park "+park1.getId()+" has been added";
		}else {
			return "Must be Logged in as an Admin to Change Park Details...";
		}
	}
	
	@PUT
	@Path("/updatepark/xml")
	@Consumes("application/xml")
	public String updatePark(Park park) {
		ParkDAO pdao=new ParkDAO();
		if(isadmin&&loggedin) {
		pdao.mergePark(park);
		return "Park "+park.getId()+" has been updated";
		}else {
			return "Must be Logged in as an Admin to Change Park Details...";
		}
	}
	
	@DELETE
	@Path("deletepark/xml")
	@Consumes("application/xml")
	public String deletePark(Park park) {
		if(isadmin&&loggedin) {
		ParkDAO pdao=new ParkDAO();
		pdao.removePark(park);
		return "Park "+park.getId()+" has been deleted";
		}else {
			return "Must be Logged in as an Admin to Change Park Details...";
		}
	} 
	
	
	//COUNCIL METHODS
	@GET
    @Path("/councils")
    @Produces("application/xml")
	public List<Council> listCouncils(){
		ParkDAO pdao=new ParkDAO();
		if(!loggedin){
			System.out.println("Must Login to View Council Details");
			return null;
		}else {
			return pdao.getAllCouncils();
		}
	}
	
	@GET
    @Path("/council/{councilid}")
    @Produces("application/xml")
    public Council getCouncil(@PathParam("councilid")String councilid){
		ParkDAO pdao=new ParkDAO();
		if(!loggedin){
			System.out.println("Must Login to View Council Details");
			return null;
		}else {
			return pdao.getCouncilById(Integer.parseInt(councilid));	
		}
    }
	
	@POST
	@Path("/addcouncil/xml")
	@Consumes("application/xml")
	public String addCouncil(Council council) {		
		ParkDAO pdao=new ParkDAO();
		if(isadmin&&loggedin) {
		Council council1=new Council(council.getName(),council.getParks());
		pdao.persistCouncil(council1);
		return "Council "+council1.getId()+" has been added";
		}else {
			return "Must be Logged in as an Admin to Change Park Details...";
		}
	}
	
	@PUT
	@Path("/updatecouncil/xml")
	@Consumes("application/xml")
	public String updateCouncil(Council council) {
		ParkDAO pdao=new ParkDAO();
		if(isadmin&&loggedin) {
		pdao.mergeCouncil(council);
		return "Council "+council.getId()+" has been updated";
		}else {
			return "Must be Logged in as an Admin to Change Park Details...";
		}
	}
	
	@DELETE
	@Path("deletecouncil/xml")
	@Consumes("application/xml")
	public String deleteCouncil(Council council) {
		ParkDAO pdao=new ParkDAO();
		if(isadmin&&loggedin) {
		pdao.removeCouncil(council);
		return "Council "+council.getId()+" has been deleted";
		}else {
			return "Must be Logged in as an Admin to Change Park Details...";
		}
	} 
	
	//USER METHODS
	@GET
    @Path("/users")
    @Produces("application/xml")
	public List<User> listUsers(){
		ParkDAO pdao=new ParkDAO();
		return pdao.getAllUsers();
	}
	
	@GET
    @Path("/user/{userid}")
    @Produces("application/xml")
    public User getUser(@PathParam("userid")String userid){
		ParkDAO pdao=new ParkDAO();
		return pdao.getUserById(Integer.parseInt(userid));			
    }
	
	@POST
	@Path("/login")
	@Consumes("application/xml")
	public String loginUser(User user) {		
		ParkDAO pdao=new ParkDAO();
		List<User> users=pdao.getAllUsers();
		for(User user1:users) {
			if(user1.getEmail().equals(user.getEmail())&&user1.getPassword().equals(user.getPassword())) {
				loggedin=true;
				if(Boolean.valueOf(user1.getAdmin())) {
					isadmin=true;
				}else {
					isadmin=false;
				}
				return "User Logged in..."+loggedin;
			}
		}
		loggedin=false;
		return "User email or password Incorrect";		
	}
	
	@POST
	@Path("/signup")
	@Consumes("application/xml")
	public String addUser(User user) {		
		ParkDAO pdao=new ParkDAO();
		System.out.println(user.getAdmin());
		User user1=new User(user.getEmail(),user.getPassword(),user.getAdmin());
		pdao.persistUser(user1);
		System.out.println(user.getAdmin());
		return "User added to db "+user1.getEmail();		
	}
	
	@PUT
	@Path("/updateuser/xml")
	@Consumes("application/xml")
	public String updateUser(User user) {
		ParkDAO pdao=new ParkDAO();
		pdao.mergeUser(user);
		return "User "+user.getId()+" has been updated";
	}
	
	@DELETE
	@Path("deleteuser/xml")
	@Consumes("application/xml")
	public String deleteUser(User user) {
		ParkDAO pdao=new ParkDAO();
		pdao.removeUser(user);
		isadmin=false;
		loggedin=false;
		return "User "+user.getId()+" has been deleted";
	}
}
