import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ReadPlaygrounds {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		// TODO Auto-generated method stub

		  File xmlFile = new File("playgrounds.xml");
	        
	        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder builder = factory.newDocumentBuilder();
	        Document doc = builder.parse(xmlFile);

	        System.out.println("Root element: " + doc.getDocumentElement().getNodeName());

	        
	        NodeList playgrounds = doc.getElementsByTagName("Play_Areas");

	        List<Park> parks=new ArrayList<>();
			ParkDAO pdao=new ParkDAO();
	        
	        for (int i = 0; i < playgrounds.getLength(); i++) {

	            Node playground = playgrounds.item(i);

	            System.out.println("\nCurrent Element: " + playground.getNodeName());

	            if (playground.getNodeType() == Node.ELEMENT_NODE) {

	                Element elem = (Element) playground;

//	                String uid = elem.getAttribute("id");

	                Node name = elem.getElementsByTagName("Name").item(0);
	                String parkname = name.getTextContent();

	                Node address1 = elem.getElementsByTagName("Address1").item(0);
	                String ad1 = address1.getTextContent();
	                
	                Node address2 = elem.getElementsByTagName("Address2").item(0);
	                String ad2 = address2.getTextContent();
	                
	                Node address3 = elem.getElementsByTagName("Address3").item(0);
	                String ad3 = address3.getTextContent();
	                
	                Node address4 = elem.getElementsByTagName("Address4").item(0);
	                String ad4 = address4.getTextContent();

	                Node phone = elem.getElementsByTagName("Phone").item(0);
	                String number = phone.getTextContent();

	                Node email = elem.getElementsByTagName("Email").item(0);
	                String parkemail = email.getTextContent();
	                
	                Node website = elem.getElementsByTagName("Website").item(0);
	                String web = website.getTextContent();
	                
	                Node type = elem.getElementsByTagName("Type").item(0);
	                String parktype = type.getTextContent();

	                Node category = elem.getElementsByTagName("Category").item(0);
	                String parkcategory = category.getTextContent();

	                Node openinghours = elem.getElementsByTagName("Opening_Hours").item(0);
	                String hours = openinghours.getTextContent();

	                Node directions = elem.getElementsByTagName("Directions").item(0);
	                String dir = directions.getTextContent();

	                Node surface = elem.getElementsByTagName("Surface_Type").item(0);
	                String surfacetype = surface.getTextContent();

	                Node comments = elem.getElementsByTagName("Comments").item(0);
	                String com = comments.getTextContent();

	                Node playtimes = elem.getElementsByTagName("Accessible_Play_Items").item(0);
	                String playtime = playtimes.getTextContent();

	                Node dparking = elem.getElementsByTagName("Disabled_Parking").item(0);
	                String parking = dparking.getTextContent();

	                Node parkranger = elem.getElementsByTagName("Park_Ranger").item(0);
	                String ranger = parkranger.getTextContent();

	                Node toilets = elem.getElementsByTagName("Toilets").item(0);
	                String toilet = toilets.getTextContent();

	                Node disabledtoilets = elem.getElementsByTagName("Disabled_Toilets").item(0);
	                String dtoilets = disabledtoilets.getTextContent();

	                Node babychanging = elem.getElementsByTagName("Baby_Changing").item(0);
	                String bchanging = babychanging.getTextContent();

	                Node seating = elem.getElementsByTagName("Seating").item(0);
	                String seats = seating.getTextContent();

	                Node drinkingwater = elem.getElementsByTagName("Drinking_Water").item(0);
	                String water = drinkingwater.getTextContent();

	                Node latitude = elem.getElementsByTagName("LAT").item(0);
	                String lat = latitude.getTextContent();

	                Node longitude = elem.getElementsByTagName("LONG").item(0);
	                String lon = longitude.getTextContent();
	                
	                //System.out.println("User id:"+ uid);
	                
	                System.out.println("Name: "+ parkname);
	                String address=ad1+", "+ad2+", "+ad3+" "+ad4;
	                System.out.println("Address: "+address);
	                System.out.println("Phone number"+number);
	                System.out.println("Email" +parkemail);
	                System.out.println("hour"+hours);
	                String facilities="";
	                if(parking.equals("Yes")) {
	                	facilities+="Parking ";
	                }
	                if(bchanging.equals("Yes")) {	
	                	facilities+="Changing Facilities ";	
	                }
	                if(toilet.equals("Yes")) {	
	                	facilities+="Toilets ";
	                }
	                if(water.equals("Yes")) {
	                	facilities+="Drinking Water ";
	                }

	                Park park=new Park(parkname,address,hours,facilities,number,parkemail);
	        		parks.add(park);
	        		pdao.persistPark(park);
//	                System.out.println(ad1);
//	                System.out.println(ad2);//put these into 1 address
//	                System.out.println(ad3);
//	                System.out.println(ad4);
//	//                String address=ad1+", "+ad2+", "+ad3+" "+ad4;
//	                System.out.println("Address: "+address);
//	                System.out.println("Phone number"+number);
//	                System.out.println("Email" +parkemail);
////	                System.out.println("web"+web);
////	                System.out.println("Type"+parktype);
////	                System.out.println("Category"+parkcategory);
//	                System.out.println("hour"+hours);
//	                System.out.println("Directions"+dir);
//	                System.out.println("suraface"+surfacetype);
//	                System.out.println("comments"+com);
//	                System.out.println("playtime"+playtime);
//	                System.out.println("parking"+parking);
////	                System.out.println("ranger"+ranger);
//	                System.out.println("toilets"+toilet);
////	                System.out.println("disablede toilets"+dtoilets);
//	                System.out.println("Baby changing"+bchanging);
////	                System.out.println("seats"+seats);
//                System.out.println("Water"+water);
////	                System.out.println("lat"+lat);
//	                System.out.println("long"+lon);
	               
System.out.println("facilities: "+facilities);
	               // System.out.println("Type"+parktype);


//	                System.out.println("Last name: " + lname);
//	                
//	                System.out.println("Occupation: " +occup);
	                
	            }
	        }
	        Council council= new Council("Fingal County Council",parks);
	        pdao.persistCouncil(council);
	}

}
