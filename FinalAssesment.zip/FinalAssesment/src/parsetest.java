import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

public class parsetest {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		// TODO Auto-generated method stub
		ReadPlaygrounds.main(args);
		dlrParkInfo.main(args);
		VisitParkInfo.main(args);	
	}

}
