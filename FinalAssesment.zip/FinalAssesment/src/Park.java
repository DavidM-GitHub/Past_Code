import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@NamedQueries({
	@NamedQuery(name="Park.findAll", query="select o from Park o"), 
	@NamedQuery(name = "Park.findById", query = "select o from Park o where o.id=:id")
})

@Entity
@XmlRootElement(name = "park")
public class Park {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	String name;
	String address;
	String hours;
	String facilities;
	String number;
	String email;
	
	public Park(String name, String address,String hours, String facilities, String number, String email) {
		this.name = name;
		this.address = address;
		this.hours=hours;
		this.facilities = facilities;
		this.number = number;
		this.email = email;
	}

	public Park() {
		
	}

	@XmlElement
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	@XmlElement
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	@XmlElement
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	@XmlElement
	public String getFacilities() {
		return facilities;
	}

	public void setFacilities(String facilities) {
		this.facilities = facilities;
	}
	
	@XmlElement
	public String getHours() {
		return hours;
	}

	public void setHours(String hours) {
		this.hours = hours;
	}
	
	@XmlElement
	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}
	@XmlElement
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Park id=" + id + ", name=" + name + ", address=" + address + ", hours=" + hours + ", facilities="
				+ facilities + ", number=" + number + ", email=" + email ;
	}


	
	
	

}
