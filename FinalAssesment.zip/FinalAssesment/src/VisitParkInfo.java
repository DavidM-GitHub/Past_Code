import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class VisitParkInfo {
	static Document doc;
static Document doc1;
static Document doc2;
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		List<Park> parks=new ArrayList<>();
		ParkDAO pdao=new ParkDAO();
		Pattern pat = Pattern.compile("Dublin\\s+([0-9]+)");
		for(int i=0;i<4;i++) {
		String pageurl="https://www.dublincity.ie/residential/parks/dublin-city-parks/visit-park?keys=&amp%3Bfacilities=All&amp%3Bpage=4&facilities=All&page="+i;
		String baseurl="https://www.dublincity.ie/residential/parks/dublin-city-parks/visit-park";
		doc=Jsoup.connect(pageurl).timeout(60000).get();

		
		Elements allh2s=doc.getElementsByTag("h2");

		ArrayList<String> titles=new ArrayList<>();
		for(Element h2:allh2s) {
			if(h2.attr("class").equalsIgnoreCase("search-result__title") ) {
				//System.out.println(h2.text());
				String h2text=h2.text().replaceAll("'","");	
				String name=h2text.replaceAll("[^a-zA-Z]+","-");	
			//	String title=name.replaceAll("/","-");
				titles.add(name);
			}
		}

	
		for (String name:titles) {
			doc1=Jsoup.connect(baseurl+"/"+name).timeout(60000).get();
			System.out.println("\nPark: "+name);
		Elements alltables=doc1.getElementsByTag("table");
//		
		String hours="";
		for(Element table:alltables) {
			if(table.text().contains("January")) {
				hours=table.text();
			}
		}
		if(!hours.equals(""))
		hours=refactorString(hours);
		System.out.println(hours);

		
		String address="";
//		
		Elements alldivs=doc1.getElementsByTag("div");
		for(Element div:alldivs) {
			if(div.attr("class").equals("location__address")) {
				address=div.text();
			//	System.out.println(address);
				if(address.substring(0,7).equals("Address")) {
					address=address.substring(8);
					//System.out.println(address);
				}
				if(address.contains("Get Directions")) {
					address=address.substring(0,address.length()-15);
					//System.out.println(address);
				}
				//take out get driections
			}			
		}
//		System.out.println(address);
		
		//if address doesnt have post code
		Matcher matcher = pat.matcher(address);
		if(!matcher.find()) {
			address=getpostcode(address);
		}
		
		System.out.println(address);

		//break address down into words
		//search li tag for this word
		
		//if found add dublin p to address
		
		String facilities="";
		for(Element div:alldivs) {
			if(div.attr("class").equals("full__facilities location__facilities text")) {
				facilities=div.text();
					//System.out.println(facilities);
					if(facilities.substring(0,10).equals("Facilities")) {
						facilities=facilities.substring(11);
						//System.out.println(facilities);
					}
			}			
		}
		System.out.println(facilities);

//		
		String phone="";
		for (Element div:alldivs) {
			if(div.attr("class").equals("field field--name-field-location-phone field--type-telephone field--label-hidden")) {
				phone=div.text();
				}
		}
		System.out.println(phone);
//		
//
		String email="parks@dublincity.ie";
		System.out.println("Email: "+email);
		
		Park park=new Park(name,address,hours,facilities,phone,email);
		parks.add(park);
		pdao.persistPark(park);
		}
		
		
		}
		Council council=new Council("Dublin City Council",parks);
		pdao.persistCouncil(council);
	}

	public static String refactorString(String text) {
		text=text.replace("after clocks go forward ","");
		text=text.replace("before clocks go back ","");
		text=text.replace("after clocks go back ","");
		text=text.replace("before clocks go forward ","");

		text=text.substring(0,text.length()-46);

		text="December & "+text;

		StringBuilder builder=new StringBuilder(text);
		builder.insert(33,"November & ");

		return builder.toString();
	}
	
	public static String getpostcode(String address) throws IOException {
		doc2=Jsoup.connect("https://en.wikipedia.org/wiki/List_of_Dublin_postal_districts").timeout(60000).get();
		String words[]=address.split(" ");
		//wordlist=Arrays.asList(words);
		boolean hascode=false;
		for(int index=0;index<words.length;index++) {
			if(words[index].length()>1) {
				if(Character.isLetter(words[index].charAt(0))&&(Character.isDigit(words[index].charAt(1)))){
					hascode=true;
				}
			}
			if((!hascode)&&(words[index].length()<5||words[index].equalsIgnoreCase("Park")||words[index].equalsIgnoreCase("Grange")||words[index].equalsIgnoreCase("Island")||
					words[index].equalsIgnoreCase("Gardens")||words[index].equalsIgnoreCase("Street")||words[index].equalsIgnoreCase("Square")||words[index].equalsIgnoreCase("Dublin")||words[index].equalsIgnoreCase("Ireland"))) {
				//System.out.println("removed "+words[index]);
				words[index]="irrelavant";
				
			}
		}
		
		Elements litags=doc2.getElementsByTag("li");
		boolean found=false;
		for(String word:words) {
			//System.out.println(word);
			for(Element li:litags) {
				if(word.equals("irrelavant")||hascode==true) {
					//do nothing
				}
				else if(word.equalsIgnoreCase("coolock")) {
					//System.out.println("Dublin 17");
					address+=" Dublin 17";
					found=true;
					break;
				}
				else if(li.text().contains(word)&&li.text().length()>9) {
					//System.out.println("Word: "+word);
				//	System.out.println("Code: "+li.text().substring(0,9));
					address+=" "+li.text().substring(0,9);
					found=true;
					break;
				}
			}
			if(found) {
				break;
			}
		}
		
		return address;
	}
	
}
