import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ParkDAO {

	protected static EntityManagerFactory emf = 
			Persistence.createEntityManagerFactory("DavesPU");
	
	public ParkDAO() {
		
	}
	
	public void persistUser(User user) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(user);
		em.getTransaction().commit();
		em.close();
	}
	
	
	public void removeUser(User user) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.remove(em.merge(user));
		em.getTransaction().commit();
		em.close();
	}
	
	public User mergeUser(User user) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		User updatedUser = em.merge(user);
		em.getTransaction().commit();
		em.close();
		return updatedUser;
	}
	
	
	public List<User> getAllUsers() {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<User> usersFromDB = new ArrayList<User>();
		usersFromDB = em.createNamedQuery("User.findAll").getResultList();
		em.getTransaction().commit();
		em.close();
		return usersFromDB;
	}
	
	public User getUserById(int id){
		EntityManager em = emf.createEntityManager();
		@SuppressWarnings("unchecked")
		List<User> users = (List<User>) 
				em.createNamedQuery("User.findById").
				setParameter("id", id).getResultList();
		em.close();
		User user = new User();
		for(User u: users) {
			user = u;
		}
		return user;
	}
	
	public void persistPark(Park park) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(park);
		em.getTransaction().commit();
		em.close();
	}
	
	
	public void removePark(Park park) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.remove(em.merge(park));
		em.getTransaction().commit();
		em.close();
	}
	
	public Park mergePark(Park park) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Park updatedPark = em.merge(park);
		em.getTransaction().commit();
		em.close();
		return updatedPark;
	}
	
	
	public List<Park> getAllParks() {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<Park> parksFromDB = new ArrayList<Park>();
		parksFromDB = em.createNamedQuery("Park.findAll").getResultList();
		em.getTransaction().commit();
		em.close();
		return parksFromDB;
	}
	
	public Park getParkById(int id){
		EntityManager em = emf.createEntityManager();
		@SuppressWarnings("unchecked")
		List<Park> parks = (List<Park>) 
				em.createNamedQuery("Park.findById").
				setParameter("id", id).getResultList();
		em.close();
		Park park = new Park();
		for(Park p: parks) {
			park = p;
		}
		return park;
	}
	
	public void persistCouncil(Council council) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(council);
		em.getTransaction().commit();
		em.close();
	}
	
	
	public void removeCouncil(Council council) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.remove(em.merge(council));
		em.getTransaction().commit();
		em.close();
	}
	
	public Council mergeCouncil(Council council) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Council updatedCouncil = em.merge(council);
		em.getTransaction().commit();
		em.close();
		return updatedCouncil;
	}
	
	
	public List<Council> getAllCouncils() {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<Council> councilsFromDB = new ArrayList<Council>();
		councilsFromDB = em.createNamedQuery("Council.findAll").getResultList();
		em.getTransaction().commit();
		em.close();
		return councilsFromDB;
	}
	
	public Council getCouncilById(int id){
		EntityManager em = emf.createEntityManager();
		@SuppressWarnings("unchecked")
		List<Council> councils = (List<Council>) 
				em.createNamedQuery("Council.findById").
				setParameter("id", id).getResultList();
		em.close();
		Council council = new Council();
		for(Council c: councils) {
			council = c;
		}
		return council;
	}
	
}
