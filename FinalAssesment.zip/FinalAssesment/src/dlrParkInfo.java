import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class dlrParkInfo {
static Document doc;
static Document doc1;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String namesurl="https://www.dlrcoco.ie/en/parks-outdoors/playgrounds";
		
		doc=Jsoup.connect(namesurl).timeout(60000).get();

		Elements alldivs=doc.getElementsByTag("div");
		String names="";
		for(Element div:alldivs) {
			if(div.attr("class").contains("field-name-body")) {
				names=div.text();
			}			
		}
		
		names=names.replaceAll(",","");
		names=names.replaceAll("'","");
		names=names.toLowerCase();
		ArrayList<String> titles=new ArrayList<>();

		String words[] =names.split(" ");
		for(int i=0;i<words.length;i++){
			if(words[i].equals("park")) {
				String title=words[i-1]+"-"+words[i];
				titles.add(title);
			}
		}
		
		for (String title:titles) {
			System.out.println(title);
		}
		List<Park> parks=new ArrayList<>();
		ParkDAO pdao=new ParkDAO();
		
		String baseurl="https://www.dlrcoco.ie/en/parks-outdoors/parks";
		for(int i=0;i<titles.size();i++) {
		System.out.println("\n"+baseurl+"/"+titles.get(i));
		try {
		doc1=Jsoup.connect(baseurl+"/"+titles.get(i)).timeout(60000).get();
		}
		catch(Exception e) {
			doc1=Jsoup.connect("https://www.dlrcoco.ie/en/parks/"+titles.get(i)).timeout(60000).get();
		}
		
		Elements parkdivs=doc1.getElementsByTag("div");
		String address="";
		
		for(Element div:parkdivs) {
			if(div.attr("class").contains("field-item even")&&div.text().contains("Dublin")) {
			//if(div.attr("class").contains("field-name-field-address")){
			String substrings[]=div.text().split("Main|Pedestrian");
			address=substrings[0];
			System.out.println(address);
			//split main or pedestrian
			}
		}
		String hours="";
		for(Element div:parkdivs) {
			if(div.attr("class").contains("entity-field-collection-item")&&div.text().contains("pm")) {
			//if(div.attr("class").contains("field-name-field-address")){
				//System.out.println(div.text());
				hours=hours+div.text()+" ";
			}
		}
		
		if(hours.contains("Opening Hours")&&hours.contains("Marlay Park")) {
			hours=hours.substring(14,hours.length()-47);
		}
		System.out.println(hours);
		
		String facilities="";
		for(Element div:parkdivs) {
			if(div.attr("class").contains("views-field-field-facility-details")) {
			//if(div.attr("class").contains("field-name-field-address")){
			//System.out.println(div.text());
				facilities=facilities+div.text();
			}
		}
		System.out.println(facilities);
//		
		Elements atags=doc1.getElementsByTag("a");
		Elements strongtags=doc1.getElementsByTag("strong");
		
		boolean mobilefound=false;
		String phone="";
		String email="";
		
		for(Element strong:strongtags) {
			if(strong.text().contains("086")) {
				phone=strong.text();
				mobilefound=true;
			}
		}		

		for (Element a:atags) {
			if(a.attr("href").contains("tel")&&!mobilefound) {
				phone=a.text();
			}
			if(a.attr("href").contains("mailto")) {
				email=a.text();
			}
		}
		
		System.out.println(phone);
		System.out.println(email);
		
		Park park=new Park(titles.get(i),address,hours,facilities,phone,email);
		parks.add(park);
		pdao.persistPark(park);
		
		}
		
Council council=new Council("Dun Laoghaire",parks);
pdao.persistCouncil(council);
	}

}
