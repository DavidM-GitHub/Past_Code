import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@NamedQueries({
	@NamedQuery(name="Council.findAll", query="select o from Council o"), 
	@NamedQuery(name = "Council.findById", query = "select o from Council o where o.id=:id")
})

@Entity
@XmlRootElement(name = "council")
public class Council {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	String name;
	
	@OneToMany(fetch = FetchType.EAGER)
	List<Park> parks;

	public Council(String name, List<Park> parks) {
		super();
		this.name = name;
		this.parks = parks;
	}

	public Council() {
		super();
		// TODO Auto-generated constructor stub
	}

	@XmlElement
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	@XmlElement
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	@XmlElement
	public List<Park> getParks() {
		return parks;
	}

	public void setParks(List<Park> parks) {
		this.parks = parks;
	}

	@Override
	public String toString() {
		String parkinfo="";
		for(Park park:parks) {
			parkinfo+="\n"+park.toString();
		}
		return "Council [name=" + name + ", parks="+parkinfo;
				
	}
	
	
}
